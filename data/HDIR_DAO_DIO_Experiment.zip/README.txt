Kitsune dataset is available for download from:
https://github.com/ymirsky/Kitsune-dataset
or
https://zenodo.org/record/3603958

This ZIP includes the elaborated ARNN-derived risk scores.
